import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df_transacoes = pd.read_csv('transacoes.csv', encoding='latin1')

df_transacoes['valor'] = df_transacoes['valor'].fillna(
    df_transacoes.groupby('estado_cliente')['valor'].transform('median')
)

df_transacoes['plataforma'] = 'Mobile'

df_transacoes['data_transacao'] = pd.to_datetime(df_transacoes['data_transacao'])
df_transacoes['data_transacao'] = df_transacoes['data_transacao'].dt.tz_localize('America/Sao_Paulo')

df_transacoes['dia_semana'] = df_transacoes['data_transacao'].dt.day_name()
df_transacoes['mes'] = df_transacoes['data_transacao'].dt.month_name()

df_transacoes = df_transacoes.drop_duplicates(keep='first')

cond_mes = df_transacoes['data_transacao'].dt.month == 9
cond_estado = (df_transacoes['estado_cliente'] == 'SP') | (df_transacoes['estado_cliente'] == 'RJ')
cond_valor = df_transacoes['valor'] > 5000.00

df_filtrado = df_transacoes[cond_mes & cond_estado & cond_valor]

risco_dict = {'C100': 'Baixo', 'C101': 'Alto', 'C102': 'Médio', 'C103': 'Alto', 'C104': 'Baixo'}
df_transacoes['nivel_risco'] = df_transacoes['id_cliente'].map(risco_dict)

pivot_risco = df_transacoes.pivot_table(
    values='valor', 
    index='mes', 
    columns='nivel_risco', 
    aggfunc='sum', 
    margins=True
)
print("--- Tabela Dinâmica de Risco (Soma do Valor) ---")
print(pivot_risco, "\n")

def calcular_zscore_por_estado(df):
    medias = df.groupby('estado_cliente')['valor'].transform('mean')
    desvios = df.groupby('estado_cliente')['valor'].transform('std')
    return (df['valor'] - medias) / desvios

df_transacoes['z_score'] = calcular_zscore_por_estado(df_transacoes)

df_anomalias = df_transacoes[df_transacoes['z_score'] > 2.5]
print(f"--- Quantidade de potenciais anomalias detectadas: {len(df_anomalias)} ---")

df_diario = df_transacoes.groupby(df_transacoes['data_transacao'].dt.date)['valor'].sum().reset_index()
df_diario.columns = ['data', 'valor_total']

df_diario['media_movel_7d'] = df_diario['valor_total'].rolling(window=7).mean()

fig, ax = plt.subplots(figsize=(12, 6))

ax.plot(df_diario['data'], df_diario['valor_total'], label='Valor Total Diário', color='skyblue', alpha=0.7)
ax.plot(df_diario['data'], df_diario['media_movel_7d'], label='Média Móvel (7 dias)', color='crimson', linewidth=2)

ax.set_ylim(bottom=0)
ax.set_title('Desempenho Financeiro Diário e Média Móvel', fontsize=14, fontweight='bold')
ax.set_xlabel('Data', fontsize=12)
ax.set_ylabel('Valor Total (R$)', fontsize=12)
ax.legend()
ax.grid(True, linestyle='--', alpha=0.5)

plt.xticks(rotation=45)
plt.tight_layout()

plt.show()
